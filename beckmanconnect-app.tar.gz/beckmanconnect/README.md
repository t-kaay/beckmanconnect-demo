# BeckmanConnect — redesigned remote support (working prototype)

A working, two-sided prototype of the redesigned BeckmanConnect experience from the case study.
The **lab (customer)** and the **field engineer** each have their own app, and they stay in sync live.

> Design prototype. Instrument data is simulated and names are fictional. Not an official Beckman Coulter product.

## Views

| URL | What it is |
| --- | --- |
| `/` | Live demo: lab and engineer side by side, with a "next step" guide and lab-type switcher |
| `/#/customer` | The lab's app on its own |
| `/#/engineer` | The engineer's service console on its own |

Open `/#/customer` and `/#/engineer` in two windows (same browser) and they sync in real time.

## The flow

1. **Choose service:** remote, hybrid and onsite side by side, with start time, downtime and cost.
2. **Request access:** the engineer asks only for the scopes the case needs; file transfer is locked off by policy.
3. **Approve access:** the lab sees who is connecting (ID verified, certified, two-factor), can narrow scopes and shorten time, or decline with a reason.
4. **Live session:** amber means connected. Every action lands in a shared log. Requests for experiment data are blocked and counted. Pause freezes the engineer out; time stops counting.
5. **Change approval:** each setting change shows before → after and why. GxP labs must e-sign with a reason.
6. **Service record:** outcome, checks, changes, blocked requests and a SHA-256 of the record; the lab signs it and can download it.

Lab types change the defaults: small lab (60 min, no IT), mid-size (60 min, IT policy), commercial / GxP (45 min, e-signed changes).

## Develop

```bash
npm install
npm run dev        # http://localhost:5173
npm test           # reducer unit tests (vitest)
npm run e2e        # end-to-end flow (Playwright)
npm run build      # static site in dist/
npm run build:single  # one self-contained HTML file in dist-single/
```

## Architecture

- `src/state/reducer.ts`: the whole session as a pure state machine (`choose → queued → awaiting_approval → live ⇄ paused → ended`). Customers can only narrow what's requested, never widen it.
- `src/state/store.ts`: one shared store synced across tabs with `BroadcastChannel`, persisted to `localStorage`. No backend, so it hosts anywhere static.
- `src/ui/Customer.tsx`, `src/ui/Engineer.tsx`: the two apps. `src/App.tsx`: routing and the split demo.

To make it multi-device (an interviewer on their laptop, you on yours), swap the store's transport for a realtime backend (e.g. Supabase Realtime or Firebase); the reducer stays the same.

## Deploy

Push to `main` on GitHub with Pages set to **GitHub Actions** (Settings → Pages → Source). `.github/workflows/deploy.yml` tests, builds and publishes.

## Use in Figma

- **Prototype (most reliable):** select a button or frame → Prototype → *On click* → *Open link* → your Pages URL. Tick "Open in new tab".
- **Inside a presentation:** Figma can't natively run an arbitrary website inside a frame. A website-embed plugin (for example Pitchdeck's iFrame embed) can play it live during a presentation.
- Use `/#/customer` or `/#/engineer` when you want just one side; use `/` for the side-by-side demo.
