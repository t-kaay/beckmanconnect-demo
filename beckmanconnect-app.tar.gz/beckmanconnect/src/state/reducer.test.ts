import { describe, expect, it } from 'vitest';
import { DEFAULT_REQUEST } from './domain';
import { initialState, reducer } from './reducer';
import type { Action, SessionState } from './types';

const T0 = 1_760_000_000_000;
const run = (s: SessionState, ...actions: Action[]) => actions.reduce(reducer, s);

function liveSession(segment: SessionState['segment'] = 'mid') {
  return run(
    initialState(T0, segment),
    { type: 'CHOOSE_SERVICE', at: T0 + 1, mode: 'remote' },
    { type: 'REQUEST_ACCESS', at: T0 + 2, scopes: DEFAULT_REQUEST, durationMin: 60, note: '' },
    { type: 'APPROVE', at: T0 + 3, scopes: DEFAULT_REQUEST, durationMin: 60, approver: 'Marcus Lee' },
  );
}

describe('session lifecycle', () => {
  it('goes choose → queued → awaiting → live', () => {
    const s = liveSession();
    expect(s.phase).toBe('live');
    expect(s.endsAt).toBe(T0 + 3 + 60 * 60_000);
    expect(s.rev).toBe(3);
  });

  it('onsite choice books a visit and can switch back to remote', () => {
    let s = run(initialState(T0), { type: 'CHOOSE_SERVICE', at: T0, mode: 'onsite' });
    expect(s.phase).toBe('onsite_booked');
    s = reducer(s, { type: 'CHOOSE_SERVICE', at: T0 + 1, mode: 'remote' });
    expect(s.phase).toBe('queued');
  });

  it('customer can narrow scopes and duration but never widen them', () => {
    const s = run(
      initialState(T0),
      { type: 'CHOOSE_SERVICE', at: T0, mode: 'remote' },
      { type: 'REQUEST_ACCESS', at: T0, scopes: { ...DEFAULT_REQUEST, screen: false }, durationMin: 30, note: '' },
      { type: 'APPROVE', at: T0, scopes: { ...DEFAULT_REQUEST, screen: true, logs: false, files: true }, durationMin: 90, approver: 'X' },
    );
    expect(s.grantedScopes).toEqual({ diagnostics: true, logs: false, screen: false, settings: true, files: false });
    expect(s.durationMin).toBe(30);
  });

  it('decline returns control to the engineer to re-request', () => {
    let s = run(
      initialState(T0),
      { type: 'CHOOSE_SERVICE', at: T0, mode: 'remote' },
      { type: 'REQUEST_ACCESS', at: T0, scopes: DEFAULT_REQUEST, durationMin: 60, note: '' },
      { type: 'DECLINE', at: T0, reason: 'Run in progress' },
    );
    expect(s.phase).toBe('declined');
    s = reducer(s, { type: 'REQUEST_ACCESS', at: T0, scopes: DEFAULT_REQUEST, durationMin: 30, note: 'after run' });
    expect(s.phase).toBe('awaiting_approval');
  });
});

describe('boundaries', () => {
  it('experiment data is always blocked and counted', () => {
    const s = reducer(liveSession(), { type: 'ENGINEER_ACTION', at: T0 + 10, action: 'openExperimentData' });
    expect(s.blockedCount).toBe(1);
    expect(s.feed.at(-1)?.kind).toBe('blocked');
  });

  it('actions outside granted scopes are blocked', () => {
    let s = run(
      initialState(T0),
      { type: 'CHOOSE_SERVICE', at: T0, mode: 'remote' },
      { type: 'REQUEST_ACCESS', at: T0, scopes: DEFAULT_REQUEST, durationMin: 60, note: '' },
      { type: 'APPROVE', at: T0, scopes: { ...DEFAULT_REQUEST, logs: false, settings: false }, durationMin: 60, approver: 'X' },
    );
    s = reducer(s, { type: 'ENGINEER_ACTION', at: T0, action: 'pullLaserLog' });
    s = reducer(s, { type: 'REQUEST_CHANGE', at: T0, param: 'violetDelay', to: 13.1, reason: 'x' });
    expect(s.blockedCount).toBe(2);
    expect(s.changes).toHaveLength(0);
  });

  it('nothing happens while paused, and paused time extends the window', () => {
    let s = reducer(liveSession(), { type: 'PAUSE', at: T0 + 1000 });
    const before = s.rev;
    s = reducer(s, { type: 'ENGINEER_ACTION', at: T0 + 2000, action: 'runQC' });
    expect(s.rev).toBe(before);
    const endsAt = s.endsAt!;
    s = reducer(s, { type: 'RESUME', at: T0 + 61_000 });
    expect(s.endsAt).toBe(endsAt + 60_000);
  });
});

describe('the fix', () => {
  it('QC fails, change is approved, QC passes, record is resolved and signed', () => {
    let s = reducer(liveSession(), { type: 'ENGINEER_ACTION', at: T0 + 10, action: 'runQC' });
    expect(s.diagnostics.at(-1)?.pass).toBe(false);
    s = reducer(s, { type: 'REQUEST_CHANGE', at: T0 + 20, param: 'violetDelay', to: 13.1, reason: 'realign' });
    const id = s.changes[0].id;
    s = reducer(s, { type: 'RESOLVE_CHANGE', at: T0 + 30, id, approve: true, by: 'Marcus Lee' });
    expect(s.params.violetDelay).toBe(13.1);
    s = reducer(s, { type: 'ENGINEER_ACTION', at: T0 + 40, action: 'runQC' });
    expect(s.diagnostics.at(-1)?.pass).toBe(true);
    s = reducer(s, { type: 'END', at: T0 + 50, by: 'engineer', reason: 'issue resolved' });
    expect(s.record?.outcome).toBe('resolved_remote');
    s = reducer(s, { type: 'SIGN_RECORD', at: T0 + 60, name: 'Marcus Lee' });
    expect(s.record?.signedBy).toBe('Marcus Lee');
  });

  it('GxP labs need a signature reason to approve a change', () => {
    let s = reducer(liveSession('commercial'), { type: 'REQUEST_CHANGE', at: T0, param: 'violetDelay', to: 13.1, reason: 'x' });
    const id = s.changes[0].id;
    const blocked = reducer(s, { type: 'RESOLVE_CHANGE', at: T0, id, approve: true, by: 'Joy Okafor' });
    expect(blocked).toBe(s);
    s = reducer(s, { type: 'RESOLVE_CHANGE', at: T0, id, approve: true, by: 'Joy Okafor', signatureReason: 'Approved per SOP-114' });
    expect(s.changes[0].status).toBe('approved');
  });

  it('only one pending change at a time', () => {
    let s = reducer(liveSession(), { type: 'REQUEST_CHANGE', at: T0, param: 'violetDelay', to: 13.1, reason: 'x' });
    s = reducer(s, { type: 'REQUEST_CHANGE', at: T0, param: 'sheathSetpoint', to: 5.2, reason: 'y' });
    expect(s.changes).toHaveLength(1);
  });
});
