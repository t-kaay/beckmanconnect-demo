import { ACTIONS, DEFAULT_REQUEST, ENGINEER, INITIAL_PARAMS, NO_SCOPES, OPTIMAL_VIOLET_DELAY, PARAMS, RCV_SPEC, SEGMENTS, fmt, rcv } from './domain';
import type { Action, DiagnosticResult, FeedItem, SessionState, Segment } from './types';

export function caseIdFor(at: number) {
  return `CS-${String(Math.floor(at / 1000) % 1000000).padStart(6, '0')}`;
}

export function initialState(at: number, segment: Segment = 'mid'): SessionState {
  return {
    version: 1,
    rev: 0,
    segment,
    phase: 'choose',
    caseId: caseIdFor(at),
    openedAt: at,
    serviceMode: null,
    requestedScopes: { ...NO_SCOPES },
    grantedScopes: { ...NO_SCOPES },
    requestNote: '',
    durationMin: SEGMENTS[segment].durationMin,
    params: { ...INITIAL_PARAMS },
    changes: [],
    diagnostics: [],
    feed: [
      {
        id: 'f-0',
        at,
        actor: 'system',
        kind: 'info',
        text: `Case opened for ${'CytoFLEX LX'} BA-21487: high CVs on the violet channel.`,
      },
    ],
    blockedCount: 0,
    currentActivity: '',
  };
}

const isLive = (s: SessionState) => s.phase === 'live';

function push(s: SessionState, item: Omit<FeedItem, 'id'>): FeedItem[] {
  return [...s.feed, { ...item, id: `f-${s.rev + 1}-${s.feed.length}` }];
}

function diagnostic(s: SessionState, kind: DiagnosticResult['kind'], at: number): DiagnosticResult {
  const id = `d-${s.rev + 1}`;
  const p = s.params;
  switch (kind) {
    case 'qc': {
      const ch = (['violet', 'blue', 'yellow', 'red'] as const).map((c) => ({ c, v: rcv(p, c, at) }));
      const pass = ch.every((x) => x.v <= RCV_SPEC);
      return {
        id,
        at,
        kind,
        title: pass ? 'Daily QC passed' : 'Daily QC failed',
        pass,
        lines: ch.map((x) => `${x.c[0].toUpperCase()}${x.c.slice(1)} rCV ${fmt(x.v)}%  ${x.v <= RCV_SPEC ? 'pass' : `fail (spec ≤ ${fmt(RCV_SPEC)}%)`}`),
      };
    }
    case 'laserLog': {
      const drift = OPTIMAL_VIOLET_DELAY - p.violetDelay;
      return {
        id,
        at,
        kind,
        title: 'Laser log, last 14 days',
        lines: [
          'Laser power: all four lasers within spec',
          `Violet (405 nm) delay: ${fmt(p.violetDelay)} µs; drifted ${fmt(Math.abs(drift))} µs since last PM`,
          Math.abs(drift) > 0.2 ? 'Likely cause of high violet CVs: delay out of alignment' : 'Violet delay within alignment window',
        ],
      };
    }
    case 'fluidics':
      return {
        id,
        at,
        kind,
        title: 'Fluidics check passed',
        pass: true,
        lines: [`Sheath pressure ${fmt(p.sheathSetpoint)} psi, stable`, 'No bubbles or clogs detected', 'Waste and sheath levels OK'],
      };
    case 'config':
      return {
        id,
        at,
        kind,
        title: 'Instrument configuration',
        lines: [
          `${PARAMS.violetDelay.label}: ${fmt(p.violetDelay)} ${PARAMS.violetDelay.unit}`,
          `${PARAMS.sheathSetpoint.label}: ${fmt(p.sheathSetpoint)} ${PARAMS.sheathSetpoint.unit}`,
          'Software: CytExpert 2.6 · 4 lasers, 14 colors',
        ],
      };
  }
}

function feedTextFor(d: DiagnosticResult): string {
  switch (d.kind) {
    case 'qc': {
      const bad = d.lines.filter((l) => l.includes('fail')).map((l) => l.split('  ')[0]);
      return d.pass ? 'Daily QC passed on all channels.' : `Daily QC failed: ${bad.join(', ')} (spec ≤ ${fmt(RCV_SPEC)}%).`;
    }
    case 'laserLog':
      return `Read the laser log. ${d.lines[1]}.`;
    case 'fluidics':
      return 'Fluidics check passed. Pressure stable.';
    case 'config':
      return 'Viewed the instrument configuration.';
  }
}

const KIND_FOR = { runQC: 'qc', pullLaserLog: 'laserLog', fluidicsCheck: 'fluidics', viewConfig: 'config' } as const;

export function reducer(s: SessionState, a: Action): SessionState {
  const next = reduce(s, a);
  return next === s ? s : { ...next, rev: s.rev + 1 };
}

function reduce(s: SessionState, a: Action): SessionState {
  const seg = SEGMENTS[s.segment];
  switch (a.type) {
    case 'RESET':
      return { ...initialState(a.at, a.segment ?? s.segment), rev: s.rev };

    case 'SET_SEGMENT':
      if (a.segment === s.segment) return s;
      return { ...initialState(a.at, a.segment), rev: s.rev };

    case 'CHOOSE_SERVICE': {
      if (s.phase !== 'choose' && s.phase !== 'onsite_booked' && s.phase !== 'declined') return s;
      if (a.mode === 'onsite') {
        return {
          ...s,
          serviceMode: 'onsite',
          phase: 'onsite_booked',
          onsiteVisit: 'Thursday, 9:00 to 12:00',
          feed: push(s, { at: a.at, actor: 'customer', kind: 'info', text: `${seg.approver} booked an onsite visit (Thursday morning).` }),
        };
      }
      return {
        ...s,
        serviceMode: a.mode,
        phase: 'queued',
        feed: push(s, {
          at: a.at,
          actor: 'customer',
          kind: 'info',
          text: `${seg.approver} chose ${a.mode === 'remote' ? 'remote' : 'hybrid (remote first, visit if needed)'} service.`,
        }),
      };
    }

    case 'REQUEST_ACCESS': {
      if (s.phase !== 'queued' && s.phase !== 'declined') return s;
      const scopes = { ...a.scopes, files: false };
      return {
        ...s,
        phase: 'awaiting_approval',
        requestedScopes: scopes,
        durationMin: a.durationMin,
        requestNote: a.note,
        declineReason: undefined,
        feed: push(s, { at: a.at, actor: 'engineer', kind: 'info', text: `${ENGINEER.short} asked for access for ${a.durationMin} minutes.` }),
      };
    }

    case 'APPROVE': {
      if (s.phase !== 'awaiting_approval') return s;
      // A customer can only narrow what was asked for, never widen it.
      const granted = { ...a.scopes };
      (Object.keys(granted) as (keyof typeof granted)[]).forEach((k) => {
        granted[k] = granted[k] && s.requestedScopes[k];
      });
      granted.files = false;
      const durationMin = Math.min(a.durationMin, s.durationMin);
      return {
        ...s,
        phase: 'live',
        grantedScopes: granted,
        durationMin,
        approvedBy: a.approver,
        startedAt: a.at,
        endsAt: a.at + durationMin * 60_000,
        currentActivity: 'Connected, reviewing the case',
        feed: push(s, { at: a.at, actor: 'customer', kind: 'ok', text: `${a.approver} approved a ${durationMin}-minute session.` }),
      };
    }

    case 'DECLINE': {
      if (s.phase !== 'awaiting_approval') return s;
      return {
        ...s,
        phase: 'declined',
        declineReason: a.reason,
        feed: push(s, { at: a.at, actor: 'customer', kind: 'warn', text: `${seg.approver} declined the request: ${a.reason}` }),
      };
    }

    case 'ENGINEER_ACTION': {
      if (!isLive(s)) return s;
      const def = ACTIONS[a.action];
      const allowed = def.needs !== 'never' && s.grantedScopes[def.needs];
      if (!allowed) {
        return {
          ...s,
          blockedCount: s.blockedCount + 1,
          feed: push(s, {
            at: a.at,
            actor: 'system',
            kind: 'blocked',
            text: `Blocked: ${def.blockedText}. ${def.needs === 'never' ? 'Experiment and sample data never leave the lab.' : 'Not in what you approved.'}`,
          }),
        };
      }
      if (a.action === 'transferFile' || a.action === 'openExperimentData') return s; // unreachable: always blocked above
      const d = diagnostic(s, KIND_FOR[a.action], a.at);
      return {
        ...s,
        currentActivity: d.title,
        diagnostics: [...s.diagnostics, d],
        feed: push(s, {
          at: a.at,
          actor: 'engineer',
          kind: d.pass === false ? 'warn' : d.pass ? 'ok' : 'action',
          text: feedTextFor(d),
        }),
      };
    }

    case 'REQUEST_CHANGE': {
      if (!isLive(s)) return s;
      if (!s.grantedScopes.settings) {
        return {
          ...s,
          blockedCount: s.blockedCount + 1,
          feed: push(s, { at: a.at, actor: 'system', kind: 'blocked', text: 'Blocked: setting change. Not in what you approved.' }),
        };
      }
      if (s.changes.some((c) => c.status === 'pending')) return s;
      const meta = PARAMS[a.param];
      const to = Math.min(meta.max, Math.max(meta.min, Math.round(a.to * 10) / 10));
      const from = s.params[a.param];
      if (to === from) return s;
      return {
        ...s,
        currentActivity: 'Waiting for your approval of a change',
        changes: [...s.changes, { id: `c-${s.rev + 1}`, param: a.param, from, to, reason: a.reason, status: 'pending', requestedAt: a.at }],
        feed: push(s, {
          at: a.at,
          actor: 'engineer',
          kind: 'change',
          text: `${ENGINEER.short} asked to change ${meta.label.toLowerCase()} from ${fmt(from)} to ${fmt(to)} ${meta.unit}.`,
        }),
      };
    }

    case 'RESOLVE_CHANGE': {
      const c = s.changes.find((x) => x.id === a.id);
      if (!c || c.status !== 'pending') return s;
      if (s.phase !== 'live' && s.phase !== 'paused') return s;
      if (a.approve && seg.eSignature && !a.signatureReason?.trim()) return s;
      const meta = PARAMS[c.param];
      const changes = s.changes.map((x) =>
        x.id === a.id
          ? { ...x, status: a.approve ? ('approved' as const) : ('declined' as const), resolvedAt: a.at, resolvedBy: a.by, signatureReason: a.signatureReason }
          : x,
      );
      return {
        ...s,
        changes,
        params: a.approve ? { ...s.params, [c.param]: c.to } : s.params,
        currentActivity: a.approve ? `Applied: ${meta.label.toLowerCase()} ${fmt(c.to)} ${meta.unit}` : 'Change declined, reviewing options',
        feed: push(s, {
          at: a.at,
          actor: 'customer',
          kind: a.approve ? 'ok' : 'warn',
          text: a.approve
            ? `${a.by} approved the change${seg.eSignature ? ' with e-signature' : ''}. ${meta.label} is now ${fmt(c.to)} ${meta.unit}.`
            : `${a.by} declined the change to ${meta.label.toLowerCase()}.`,
        }),
      };
    }

    case 'PAUSE':
      if (!isLive(s)) return s;
      return {
        ...s,
        phase: 'paused',
        pausedAt: a.at,
        feed: push(s, { at: a.at, actor: 'customer', kind: 'warn', text: `${seg.approver} paused the session. The engineer cannot see or do anything.` }),
      };

    case 'RESUME': {
      if (s.phase !== 'paused' || s.pausedAt === undefined || s.endsAt === undefined) return s;
      const pausedFor = a.at - s.pausedAt;
      return {
        ...s,
        phase: 'live',
        pausedAt: undefined,
        endsAt: s.endsAt + pausedFor, // paused time doesn't count against the window
        feed: push(s, { at: a.at, actor: 'customer', kind: 'ok', text: `${seg.approver} resumed the session.` }),
      };
    }

    case 'END': {
      if (s.phase !== 'live' && s.phase !== 'paused') return s;
      const lastQC = [...s.diagnostics].reverse().find((d) => d.kind === 'qc');
      const outcome = a.outcome ?? (lastQC?.pass ? 'resolved_remote' : 'unresolved');
      const who = a.by === 'customer' ? seg.approver : a.by === 'engineer' ? ENGINEER.short : 'System';
      return {
        ...s,
        phase: 'ended',
        endedAt: a.at,
        pausedAt: undefined,
        currentActivity: '',
        record: {
          outcome,
          endedBy: a.by,
          endReason: a.reason,
          summary:
            a.summary ??
            (outcome === 'resolved_remote'
              ? 'Violet laser delay realigned remotely. Daily QC passed on all channels. No visit needed.'
              : 'Not resolved remotely. Diagnostics attached so the visiting engineer arrives with the right parts.'),
        },
        feed: push(s, { at: a.at, actor: a.by, kind: 'info', text: `${who} ended the session: ${a.reason}. Access closed.` }),
      };
    }

    case 'SIGN_RECORD':
      if (s.phase !== 'ended' || !s.record || s.record.signedBy || !a.name.trim()) return s;
      return {
        ...s,
        record: { ...s.record, signedBy: a.name.trim(), signedAt: a.at },
        feed: push(s, { at: a.at, actor: 'customer', kind: 'ok', text: `${a.name.trim()} signed the service record.` }),
      };
  }
}

export const defaultRequest = () => ({ ...DEFAULT_REQUEST });
