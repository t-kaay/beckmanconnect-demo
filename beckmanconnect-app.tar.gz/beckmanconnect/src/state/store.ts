import { useEffect, useState, useSyncExternalStore } from 'react';
import { initialState, reducer } from './reducer';
import type { Action, SessionState } from './types';

/**
 * One shared session, synced across every open tab/window of the demo.
 * BroadcastChannel carries live updates; localStorage keeps state across reloads
 * and acts as a fallback channel (storage events) where BroadcastChannel is missing.
 */
const KEY = 'beckmanconnect-demo-v1';

function load(): SessionState {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as SessionState;
      if (parsed && parsed.version === 1) return parsed;
    }
  } catch {
    /* storage unavailable: fall back to memory */
  }
  return initialState(Date.now());
}

let state: SessionState = load();
const listeners = new Set<() => void>();
let channel: BroadcastChannel | null = null;
try {
  channel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel(KEY) : null;
} catch {
  channel = null;
}

function set(next: SessionState, broadcast: boolean) {
  if (next === state) return;
  state = next;
  if (broadcast) {
    try {
      localStorage.setItem(KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
    try {
      channel?.postMessage(next);
    } catch {
      /* ignore */
    }
  }
  listeners.forEach((l) => l());
}

function adopt(incoming: SessionState | null) {
  if (!incoming || incoming.version !== 1) return;
  // Accept anything that is newer, or a fresh reset (different case).
  if (incoming.rev > state.rev || incoming.caseId !== state.caseId || incoming.openedAt !== state.openedAt) {
    set(incoming, false);
  }
}

channel?.addEventListener('message', (e: MessageEvent<SessionState>) => adopt(e.data));
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key !== KEY || !e.newValue) return;
    try {
      adopt(JSON.parse(e.newValue));
    } catch {
      /* ignore */
    }
  });
}

export function dispatch(action: Action) {
  set(reducer(state, action), true);
}

export function getState() {
  return state;
}

function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}

export function useSession(): SessionState {
  return useSyncExternalStore(subscribe, getState, getState);
}

export function useNow(intervalMs = 1000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

/** Ends the session when its approved window runs out. Safe to mount in several views. */
export function useExpiryWatch() {
  const s = useSession();
  const now = useNow(1000);
  useEffect(() => {
    if (s.phase === 'live' && s.endsAt && now >= s.endsAt) {
      dispatch({ type: 'END', at: now, by: 'system', reason: 'approved time ran out' });
    }
  }, [s.phase, s.endsAt, now]);
}
