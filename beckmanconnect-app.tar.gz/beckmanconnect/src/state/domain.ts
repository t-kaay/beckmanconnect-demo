import type { EngineerActionKey, InstrumentParams, ParamKey, ScopeDef, ScopeKey, Scopes, Segment } from './types';

export const ENGINEER = {
  name: 'Dana Mercer',
  short: 'Dana M.',
  role: 'Field Service Engineer',
  cert: 'Certified: flow cytometry',
  region: 'Central region',
  initials: 'DM',
};

export const INSTRUMENT = {
  model: 'CytoFLEX LX',
  kind: 'Flow cytometer',
  serial: 'BA-21487',
  location: 'Bench 3',
  issue: 'High CVs on the violet channel since Tuesday; QC beads failing',
};

export interface SegmentProfile {
  key: Segment;
  label: string;
  lab: string;
  approver: string;
  approverRole: string;
  durationMin: number;
  /** Commercial / GxP labs sign every setting change with a reason. */
  eSignature: boolean;
  plan: string;
  itNote: string;
}

export const SEGMENTS: Record<Segment, SegmentProfile> = {
  small: {
    key: 'small',
    label: 'Small lab',
    lab: 'Riverbend Cell Lab',
    approver: 'Priya Shah',
    approverRole: 'Lab manager',
    durationMin: 60,
    eSignature: false,
    plan: 'Warranty',
    itNote: 'No IT team. Connection check passed at setup.',
  },
  mid: {
    key: 'mid',
    label: 'Mid-size lab',
    lab: 'Northfield Biologics · Assay Lab B',
    approver: 'Marcus Lee',
    approverRole: 'Lab operations lead',
    durationMin: 60,
    eSignature: false,
    plan: 'PM Plus service plan',
    itNote: 'IT policy: sessions up to 90 min, outbound port 443 only.',
  },
  commercial: {
    key: 'commercial',
    label: 'Commercial / GxP',
    lab: 'Halden Therapeutics · QC Lab 2',
    approver: 'Joy Okafor',
    approverRole: 'QA-designated approver',
    durationMin: 45,
    eSignature: true,
    plan: 'Enterprise service agreement',
    itNote: 'IT policy: 45 min max, every change e-signed with a reason.',
  },
};

export const SCOPES: ScopeDef[] = [
  { key: 'diagnostics', label: 'Run diagnostics and QC', detail: 'Start built-in checks and read the results.' },
  { key: 'logs', label: 'Read instrument logs', detail: 'Error, laser and fluidics logs. No sample names.' },
  { key: 'screen', label: 'See the instrument screen', detail: 'View only. They cannot click or type.' },
  { key: 'settings', label: 'Propose setting changes', detail: 'Each change asks you first, with before and after values.' },
  {
    key: 'files',
    label: 'Transfer files',
    detail: 'Copy files to or from the instrument PC.',
    lockedReason: 'Off by policy: experiment and sample files stay in the lab.',
  },
];

export const DEFAULT_REQUEST: Scopes = {
  diagnostics: true,
  logs: true,
  screen: true,
  settings: true,
  files: false,
};

export const NO_SCOPES: Scopes = { diagnostics: false, logs: false, screen: false, settings: false, files: false };

export const INITIAL_PARAMS: InstrumentParams = { violetDelay: 12.4, sheathSetpoint: 5.0 };
export const OPTIMAL_VIOLET_DELAY = 13.1;
export const RCV_SPEC = 5.0;

export const PARAMS: Record<ParamKey, { label: string; unit: string; step: number; min: number; max: number }> = {
  violetDelay: { label: 'Violet laser (405 nm) delay', unit: 'µs', step: 0.1, min: 10, max: 16 },
  sheathSetpoint: { label: 'Sheath pressure setpoint', unit: 'psi', step: 0.1, min: 4, max: 6 },
};

export const ACTIONS: Record<
  EngineerActionKey,
  { label: string; needs: ScopeKey | 'never'; activity: string; blockedText: string }
> = {
  runQC: { label: 'Run daily QC', needs: 'diagnostics', activity: 'Running daily QC with QC beads', blockedText: 'Run QC' },
  pullLaserLog: { label: 'Pull laser log', needs: 'logs', activity: 'Reading the laser log', blockedText: 'Read laser log' },
  fluidicsCheck: { label: 'Fluidics check', needs: 'diagnostics', activity: 'Checking fluidics pressure', blockedText: 'Fluidics check' },
  viewConfig: { label: 'View configuration', needs: 'screen', activity: 'Viewing instrument configuration', blockedText: 'View screen' },
  openExperimentData: {
    label: 'Open experiment data',
    needs: 'never',
    activity: '',
    blockedText: 'Request to open experiment data',
  },
  transferFile: { label: 'Transfer a file', needs: 'files', activity: 'Transferring a file', blockedText: 'File transfer' },
};

/** Deterministic-ish rCV for a channel, from current params plus small noise. */
export function rcv(params: InstrumentParams, channel: 'violet' | 'blue' | 'red' | 'yellow', t: number): number {
  const wobble = Math.sin(t / 1700 + channel.length) * 0.12 + Math.sin(t / 530 + channel.length * 3) * 0.06;
  if (channel === 'violet') {
    return Math.max(1.8, 2.3 + Math.abs(params.violetDelay - OPTIMAL_VIOLET_DELAY) * 6 + wobble);
  }
  const base = { blue: 2.1, red: 2.5, yellow: 2.3 }[channel];
  return base + Math.abs(params.sheathSetpoint - 5.0) * 2 + wobble;
}

export function fmt(n: number, d = 1) {
  return n.toFixed(d);
}
