export type Segment = 'small' | 'mid' | 'commercial';
export type ServiceMode = 'remote' | 'hybrid' | 'onsite';

export type Phase =
  | 'choose' // customer picks remote / hybrid / onsite
  | 'queued' // remote chosen, waiting for the engineer to request access
  | 'awaiting_approval' // engineer asked, customer deciding
  | 'declined'
  | 'live'
  | 'paused'
  | 'ended'
  | 'onsite_booked';

export type ScopeKey = 'diagnostics' | 'logs' | 'screen' | 'settings' | 'files';

export interface ScopeDef {
  key: ScopeKey;
  label: string;
  detail: string;
  /** Can this scope ever be granted? `files` is locked for PHI-class instruments. */
  lockedReason?: string;
}

export type Scopes = Record<ScopeKey, boolean>;

export type Actor = 'customer' | 'engineer' | 'system';

export interface FeedItem {
  id: string;
  at: number;
  actor: Actor;
  text: string;
  kind?: 'info' | 'action' | 'blocked' | 'change' | 'warn' | 'ok';
}

export interface ChangeRequest {
  id: string;
  param: ParamKey;
  from: number;
  to: number;
  reason: string;
  status: 'pending' | 'approved' | 'declined';
  requestedAt: number;
  resolvedAt?: number;
  resolvedBy?: string;
  signatureReason?: string;
}

export type ParamKey = 'violetDelay' | 'sheathSetpoint';

export interface InstrumentParams {
  violetDelay: number; // µs, laser delay for 405 nm
  sheathSetpoint: number; // psi
}

export interface DiagnosticResult {
  id: string;
  at: number;
  kind: 'qc' | 'laserLog' | 'fluidics' | 'config';
  title: string;
  lines: string[];
  pass?: boolean;
}

export interface ServiceRecord {
  outcome: 'resolved_remote' | 'visit_needed' | 'unresolved';
  endedBy: Actor;
  endReason: string;
  summary: string;
  signedBy?: string;
  signedAt?: number;
}

export interface SessionState {
  version: 1;
  rev: number;
  segment: Segment;
  phase: Phase;
  caseId: string;
  openedAt: number;
  serviceMode: ServiceMode | null;
  requestedScopes: Scopes;
  grantedScopes: Scopes;
  requestNote: string;
  durationMin: number;
  approvedBy?: string;
  declineReason?: string;
  startedAt?: number;
  endsAt?: number;
  pausedAt?: number;
  endedAt?: number;
  params: InstrumentParams;
  changes: ChangeRequest[];
  diagnostics: DiagnosticResult[];
  feed: FeedItem[];
  blockedCount: number;
  currentActivity: string;
  record?: ServiceRecord;
  onsiteVisit?: string;
}

export type Action =
  | { type: 'RESET'; at: number; segment?: Segment }
  | { type: 'SET_SEGMENT'; at: number; segment: Segment }
  | { type: 'CHOOSE_SERVICE'; at: number; mode: ServiceMode }
  | { type: 'REQUEST_ACCESS'; at: number; scopes: Scopes; durationMin: number; note: string }
  | { type: 'APPROVE'; at: number; scopes: Scopes; durationMin: number; approver: string }
  | { type: 'DECLINE'; at: number; reason: string }
  | { type: 'ENGINEER_ACTION'; at: number; action: EngineerActionKey }
  | { type: 'REQUEST_CHANGE'; at: number; param: ParamKey; to: number; reason: string }
  | { type: 'RESOLVE_CHANGE'; at: number; id: string; approve: boolean; by: string; signatureReason?: string }
  | { type: 'PAUSE'; at: number }
  | { type: 'RESUME'; at: number }
  | { type: 'END'; at: number; by: Actor; reason: string; outcome?: ServiceRecord['outcome']; summary?: string }
  | { type: 'SIGN_RECORD'; at: number; name: string };

export type EngineerActionKey = 'runQC' | 'pullLaserLog' | 'fluidicsCheck' | 'viewConfig' | 'openExperimentData' | 'transferFile';
