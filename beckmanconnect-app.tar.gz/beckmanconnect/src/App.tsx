import { useEffect, useState } from 'react';
import { SEGMENTS } from './state/domain';
import { dispatch, useExpiryWatch, useSession } from './state/store';
import type { Segment, SessionState } from './state/types';
import { CustomerApp } from './ui/Customer';
import { EngineerApp } from './ui/Engineer';

type Route = 'demo' | 'customer' | 'engineer';

function readRoute(): Route {
  const h = window.location.hash.replace(/^#\/?/, '');
  return h === 'customer' || h === 'engineer' ? h : 'demo';
}

export default function App() {
  const [route, setRoute] = useState<Route>(readRoute);
  useEffect(() => {
    const on = () => setRoute(readRoute());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  useExpiryWatch();
  if (route === 'customer') return <CustomerApp />;
  if (route === 'engineer') return <EngineerApp />;
  return <Demo />;
}

/** What to do next, so a presenter (or an interviewer clicking around in Figma) never gets lost. */
export function nextStep(s: SessionState): { who: 'Lab' | 'Engineer' | 'Done'; text: string } {
  const lastQC = [...s.diagnostics].reverse().find((d) => d.kind === 'qc');
  const approved = s.changes.some((c) => c.status === 'approved');
  switch (s.phase) {
    case 'choose':
      return { who: 'Lab', text: 'Compare the options, then start remote.' };
    case 'onsite_booked':
      return { who: 'Lab', text: 'Visit booked for Thursday. Try "Try remote first" to see the faster path.' };
    case 'queued':
      return { who: 'Engineer', text: 'Review the scopes and send the access request.' };
    case 'declined':
      return { who: 'Engineer', text: 'Send a new request, or the lab can book a visit.' };
    case 'awaiting_approval':
      return { who: 'Lab', text: 'Review who is connecting and what they can do, then approve.' };
    case 'paused':
      return { who: 'Lab', text: 'The engineer is frozen out. Resume when ready.' };
    case 'live': {
      if (s.changes.some((c) => c.status === 'pending')) return { who: 'Lab', text: 'Approve the setting change, with before and after values.' };
      if (!lastQC) return { who: 'Engineer', text: 'Run daily QC. Violet will fail.' };
      if (lastQC.pass) return { who: 'Engineer', text: 'QC passes. End the session as resolved.' };
      if (approved) return { who: 'Engineer', text: 'Re-run daily QC to confirm the fix.' };
      if (!s.diagnostics.some((d) => d.kind === 'laserLog')) return { who: 'Engineer', text: 'Pull the laser log to find the cause.' };
      return { who: 'Engineer', text: 'Propose the violet delay change. Try "Open experiment data" too: it gets blocked.' };
    }
    case 'ended':
      return s.record?.signedBy
        ? { who: 'Done', text: 'Resolved remotely and signed. Reset, or switch lab type to see different defaults.' }
        : { who: 'Lab', text: 'Review and sign the service record.' };
  }
}

function Demo() {
  const s = useSession();
  const step = nextStep(s);
  const [tab, setTab] = useState<'customer' | 'engineer'>('customer');
  // On narrow screens, follow the action to whichever side needs to act next.
  useEffect(() => {
    if (step.who === 'Lab') setTab('customer');
    if (step.who === 'Engineer') setTab('engineer');
  }, [step.who, s.phase]);

  const base = window.location.href.split('#')[0];
  return (
    <div className="demo">
      <div className="demo-bar">
        <strong style={{ fontFamily: 'var(--f-display)', fontSize: 17 }}>BeckmanConnect · live demo</strong>
        <div className="seg" role="group" aria-label="Lab type">
          {(Object.keys(SEGMENTS) as Segment[]).map((k) => (
            <button key={k} aria-pressed={s.segment === k} onClick={() => dispatch({ type: 'SET_SEGMENT', at: Date.now(), segment: k })}>
              {SEGMENTS[k].label}
            </button>
          ))}
        </div>
        <div className="guide" aria-live="polite">
          <span className="step">{step.who === 'Done' ? 'DONE' : `NEXT · ${step.who.toUpperCase()}`}</span>
          <span>{step.text}</span>
        </div>
        <button className="btn small" onClick={() => dispatch({ type: 'RESET', at: Date.now() })}>
          Reset
        </button>
      </div>
      <div className="tabs" role="tablist">
        <button role="tab" aria-selected={tab === 'customer'} onClick={() => setTab('customer')}>
          Lab (customer)
          {step.who === 'Lab' && tab !== 'customer' && <span className="ping" aria-label="needs action" />}
        </button>
        <button role="tab" aria-selected={tab === 'engineer'} onClick={() => setTab('engineer')}>
          Field engineer
          {step.who === 'Engineer' && tab !== 'engineer' && <span className="ping" aria-label="needs action" />}
        </button>
      </div>
      <div className="panes">
        <section className="pane" data-hidden={tab !== 'customer'} aria-label="Lab view">
          <div className="pane-label">
            <span>Lab · {SEGMENTS[s.segment].approver}</span>
            <a href={`${base}#/customer`} target="_blank" rel="noreferrer" style={{ color: 'inherit' }}>
              Open alone ↗
            </a>
          </div>
          <div className="pane-body">
            <CustomerApp />
          </div>
        </section>
        <section className="pane" data-hidden={tab !== 'engineer'} aria-label="Engineer view">
          <div className="pane-label">
            <span>Beckman · field engineer</span>
            <a href={`${base}#/engineer`} target="_blank" rel="noreferrer" style={{ color: 'inherit' }}>
              Open alone ↗
            </a>
          </div>
          <div className="pane-body">
            <EngineerApp />
          </div>
        </section>
      </div>
    </div>
  );
}
