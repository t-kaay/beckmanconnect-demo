import { useEffect, useRef, useState } from 'react';
import { ACTIONS, DEFAULT_REQUEST, ENGINEER, INSTRUMENT, OPTIMAL_VIOLET_DELAY, PARAMS, RCV_SPEC, SCOPES, SEGMENTS, fmt, rcv } from '../state/domain';
import { dispatch, useNow, useSession } from '../state/store';
import type { EngineerActionKey, ParamKey, Scopes, SessionState } from '../state/types';
import { Feed, InstrumentLine, Logo, ScopeChecks, ServiceRecordView, SimNote, mmss, remaining } from './shared';

export function EngineerApp() {
  const s = useSession();
  return (
    <div className="app engineer">
      <header className="appbar">
        <Logo sub="Service console" />
        <span className="muted bar-meta" style={{ marginLeft: 'auto', fontSize: 13.5, textAlign: 'right' }}>
          {ENGINEER.name} · 2FA ✓
        </span>
      </header>
      <main>
        <section className="card stack">
          <InstrumentLine s={s} />
          <p style={{ fontSize: 14 }}>
            <strong>Reported:</strong> {INSTRUMENT.issue}
          </p>
          <p className="muted" style={{ fontSize: 13 }}>
            {SEGMENTS[s.segment].label} · {SEGMENTS[s.segment].itNote}
          </p>
        </section>
        <Body s={s} />
      </main>
      <SimNote />
    </div>
  );
}

function Body({ s }: { s: SessionState }) {
  switch (s.phase) {
    case 'choose':
      return <Waiting title="Waiting for the lab to choose a service type" text="The customer sees remote, hybrid and onsite side by side." />;
    case 'onsite_booked':
      return <Waiting title={`Onsite visit booked: ${s.onsiteVisit}`} text="The customer can still switch to remote. Nothing to do yet." still />;
    case 'queued':
    case 'declined':
      return <RequestBuilder s={s} />;
    case 'awaiting_approval':
      return (
        <section className="card stack">
          <div className="row" style={{ '--gap': '10px' } as React.CSSProperties}>
            <div className="spinner" aria-hidden />
            <h2>Waiting for {SEGMENTS[s.segment].approver} to approve</h2>
          </div>
          <p className="muted">
            Requested {s.durationMin} minutes. The customer may narrow access or shorten the time.
          </p>
          <ScopeChecks scopes={s.requestedScopes} />
        </section>
      );
    case 'live':
    case 'paused':
      return <Session s={s} />;
    case 'ended':
      return (
        <>
          <ServiceRecordView s={s} canSign={false} />
          <section className="card stack">
            <h3>Session log</h3>
            <Feed items={s.feed} />
          </section>
        </>
      );
  }
}

function Waiting({ title, text, still }: { title: string; text: string; still?: boolean }) {
  return (
    <section className="card empty">
      {!still && <div className="spinner" aria-hidden />}
      <h3 style={{ color: 'var(--ink)' }}>{title}</h3>
      <p>{text}</p>
    </section>
  );
}

function RequestBuilder({ s }: { s: SessionState }) {
  const seg = SEGMENTS[s.segment];
  const max = seg.durationMin === 45 ? 45 : 90;
  const [scopes, setScopes] = useState<Scopes>({ ...DEFAULT_REQUEST });
  const [duration, setDuration] = useState(seg.durationMin);
  const [note, setNote] = useState(
    "Your QC shows high CVs on the violet channel. I'd like to run QC and read the laser log. Any setting change will ask you first.",
  );
  return (
    <section className="card stack" style={{ '--gap': '14px' } as React.CSSProperties} aria-labelledby="req-h">
      {s.phase === 'declined' && (
        <div className="badge critical" style={{ alignSelf: 'flex-start' }}>
          Declined: {s.declineReason}
        </div>
      )}
      <div>
        <div className="eyebrow">{s.serviceMode === 'hybrid' ? 'Hybrid' : 'Remote'} service chosen</div>
        <h2 id="req-h" style={{ marginTop: 4 }}>
          Request access
        </h2>
        <p className="muted" style={{ fontSize: 14 }}>
          Ask only for what this case needs. The lab sees exactly this list.
        </p>
      </div>
      <div>
        {SCOPES.map((d) => (
          <div className="scope" key={d.key}>
            <div>
              <div className="t" id={`rq-${d.key}`}>
                {d.label}
              </div>
              <div className="d">{d.lockedReason ?? d.detail}</div>
            </div>
            <label className="switch">
              <input
                type="checkbox"
                aria-labelledby={`rq-${d.key}`}
                checked={scopes[d.key] && !d.lockedReason}
                disabled={!!d.lockedReason}
                onChange={(e) => setScopes({ ...scopes, [d.key]: e.target.checked })}
              />
              <span />
            </label>
          </div>
        ))}
      </div>
      <div className="grid2">
        <label className="field">
          Duration
          <select className="input" value={duration} onChange={(e) => setDuration(Number(e.target.value))}>
            {[15, 30, 45, 60, 90]
              .filter((d) => d <= max)
              .map((d) => (
                <option key={d} value={d}>
                  {d} minutes
                </option>
              ))}
          </select>
        </label>
        <label className="field">
          Note to the lab
          <textarea className="input" value={note} onChange={(e) => setNote(e.target.value)} />
        </label>
      </div>
      <div className="row">
        <button className="btn primary" onClick={() => dispatch({ type: 'REQUEST_ACCESS', at: Date.now(), scopes, durationMin: duration, note })}>
          Send access request
        </button>
      </div>
    </section>
  );
}

const ACTION_ORDER: EngineerActionKey[] = ['runQC', 'pullLaserLog', 'fluidicsCheck', 'viewConfig', 'openExperimentData'];

function Session({ s }: { s: SessionState }) {
  const now = useNow(1000);
  const paused = s.phase === 'paused';
  const left = remaining(s, now);
  const lastQC = [...s.diagnostics].reverse().find((d) => d.kind === 'qc');
  return (
    <>
      <div className={`livebar${paused ? ' paused' : ''}`} role="status">
        <span className="who">
          <span className={`dot${paused ? '' : ' pulse'}`} style={{ color: paused ? 'var(--muted)' : 'var(--live-fill)' }} />
          {paused ? 'Paused by customer' : 'Connected'}
        </span>
        <span className="grow mono">
          {mmss(left)} left · approved by {s.approvedBy}
        </span>
        <button
          className="btn small"
          disabled={paused}
          onClick={() =>
            dispatch({
              type: 'END',
              at: Date.now(),
              by: 'engineer',
              reason: 'visit needed',
              outcome: 'visit_needed',
              summary: 'Remote diagnosis complete. A visit is booked and the engineer arrives with the right part.',
            })
          }
        >
          Needs a visit
        </button>
        <button
          className="btn primary small"
          disabled={paused}
          onClick={() => dispatch({ type: 'END', at: Date.now(), by: 'engineer', reason: lastQC?.pass ? 'issue resolved' : 'work complete' })}
        >
          End session
        </button>
      </div>

      <div className={`grid2${paused ? ' paused-veil' : ''}`}>
        <Telemetry s={s} />
        <section className="card stack" aria-labelledby="act-h">
          <h3 id="act-h">Actions</h3>
          {ACTION_ORDER.map((k) => {
            const def = ACTIONS[k];
            const allowed = def.needs !== 'never' && s.grantedScopes[def.needs];
            return (
              <button
                key={k}
                className="btn action-btn"
                disabled={paused}
                onClick={() => dispatch({ type: 'ENGINEER_ACTION', at: Date.now(), action: k })}
              >
                <span>{def.label}</span>
                {!allowed && <span className="lock">🔒 {def.needs === 'never' ? 'Always blocked' : 'Not approved'}</span>}
              </button>
            );
          })}
        </section>
      </div>

      <div className={`grid2${paused ? ' paused-veil' : ''}`}>
        <ChangeForm s={s} disabled={paused} />
        <section className="card stack" aria-labelledby="res-h">
          <h3 id="res-h">Results</h3>
          {s.diagnostics.length === 0 && <p className="muted">Run a check to see results here.</p>}
          {[...s.diagnostics]
            .reverse()
            .slice(0, 4)
            .map((d) => (
              <div key={d.id} className={`result ${d.pass === undefined ? '' : d.pass ? 'pass' : 'fail'}`}>
                <div className="row spread">
                  <strong>{d.title}</strong>
                  <span className="muted mono">{new Date(d.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}</span>
                </div>
                <ul>
                  {d.lines.map((l) => (
                    <li key={l}>{l}</li>
                  ))}
                </ul>
              </div>
            ))}
        </section>
      </div>
      <section className="card stack">
        <h3>Session log (the lab sees the same)</h3>
        <Feed items={s.feed} limit={8} />
      </section>
    </>
  );
}

const CHANNELS = ['violet', 'blue', 'yellow', 'red'] as const;

function Telemetry({ s }: { s: SessionState }) {
  const now = useNow(1000);
  const hist = useRef<number[]>([]);
  const [, force] = useState(0);
  const violet = rcv(s.params, 'violet', now);
  useEffect(() => {
    hist.current = [...hist.current, violet].slice(-40);
    force((n) => n + 1);
  }, [now]); // eslint-disable-line react-hooks/exhaustive-deps

  const allowed = s.grantedScopes.diagnostics || s.grantedScopes.screen;
  const W = 260;
  const H = 54;
  const maxV = 10;
  const pts = hist.current.map((v, i) => `${(i / 39) * W},${H - (Math.min(v, maxV) / maxV) * H}`).join(' ');
  const specY = H - (RCV_SPEC / maxV) * H;

  return (
    <section className="card stack" aria-labelledby="tel-h">
      <div className="row spread">
        <h3 id="tel-h">Live instrument health</h3>
        <span className="badge">rCV, QC beads</span>
      </div>
      {!allowed ? (
        <p className="muted">Not approved for diagnostics or screen view.</p>
      ) : (
        <>
          {CHANNELS.map((c) => {
            const v = rcv(s.params, c, now);
            return (
              <div className="meter" key={c}>
                <span style={{ textTransform: 'capitalize' }}>{c}</span>
                <span className="bar" role="meter" aria-valuenow={Number(v.toFixed(1))} aria-valuemin={0} aria-valuemax={maxV} aria-label={`${c} rCV`}>
                  <span className={`fill${v > RCV_SPEC ? ' bad' : ''}`} style={{ width: `${(Math.min(v, maxV) / maxV) * 100}%` }} />
                  <span className="spec" style={{ left: `${(RCV_SPEC / maxV) * 100}%` }} />
                </span>
                <span className="v">{fmt(v)}%</span>
              </div>
            );
          })}
          <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label="Violet rCV over the last 40 seconds" style={{ overflow: 'visible' }}>
            <line x1="0" x2={W} y1={specY} y2={specY} stroke="var(--muted)" strokeDasharray="3 3" strokeWidth="1" />
            <text x={W} y={specY - 4} textAnchor="end" fontSize="10" fill="var(--muted)" fontFamily="var(--f-mono)">
              spec {fmt(RCV_SPEC)}%
            </text>
            {hist.current.length > 1 && <polyline points={pts} fill="none" stroke={violet > RCV_SPEC ? 'var(--critical)' : 'var(--brand)'} strokeWidth="2" />}
          </svg>
          <p className="muted" style={{ fontSize: 12.5 }}>
            Violet delay {fmt(s.params.violetDelay)} µs (aligned at {fmt(OPTIMAL_VIOLET_DELAY)} µs). Instrument health only; no sample data.
          </p>
        </>
      )}
    </section>
  );
}

function ChangeForm({ s, disabled }: { s: SessionState; disabled: boolean }) {
  const [param, setParam] = useState<ParamKey>('violetDelay');
  const [to, setTo] = useState<string>(fmt(OPTIMAL_VIOLET_DELAY));
  const [reason, setReason] = useState('Laser log shows the violet delay drifted 0.7 µs. Realigning should bring violet CVs back in spec.');
  const pending = s.changes.find((c) => c.status === 'pending');
  const meta = PARAMS[param];
  const allowed = s.grantedScopes.settings;
  const lastChange = s.changes.at(-1);

  return (
    <section className="card stack" aria-labelledby="chg-form-h">
      <h3 id="chg-form-h">Propose a setting change</h3>
      {!allowed && <p className="badge critical" style={{ alignSelf: 'flex-start' }}>Settings not approved by the lab</p>}
      {pending ? (
        <div className="stack" style={{ '--gap': '8px' } as React.CSSProperties}>
          <div className="row" style={{ '--gap': '8px' } as React.CSSProperties}>
            <div className="spinner" aria-hidden />
            <strong>Waiting for the lab to approve</strong>
          </div>
          <p className="mono">
            {PARAMS[pending.param].label}: {fmt(pending.from)} → {fmt(pending.to)} {PARAMS[pending.param].unit}
          </p>
        </div>
      ) : (
        <form
          className="stack"
          onSubmit={(e) => {
            e.preventDefault();
            dispatch({ type: 'REQUEST_CHANGE', at: Date.now(), param, to: Number(to), reason });
          }}
        >
          <div className="grid2" style={{ gap: 12 }}>
            <label className="field">
              Setting
              <select
                className="input"
                value={param}
                onChange={(e) => {
                  const p = e.target.value as ParamKey;
                  setParam(p);
                  setTo(fmt(p === 'violetDelay' ? OPTIMAL_VIOLET_DELAY : s.params[p]));
                }}
              >
                {(Object.keys(PARAMS) as ParamKey[]).map((k) => (
                  <option key={k} value={k}>
                    {PARAMS[k].label}
                  </option>
                ))}
              </select>
            </label>
            <label className="field">
              New value ({meta.unit}) · now {fmt(s.params[param])}
              <input className="input" type="number" step={meta.step} min={meta.min} max={meta.max} value={to} onChange={(e) => setTo(e.target.value)} />
            </label>
          </div>
          <label className="field">
            Reason the lab will see
            <textarea className="input" value={reason} onChange={(e) => setReason(e.target.value)} />
          </label>
          <div className="row">
            <button className="btn primary" type="submit" disabled={disabled || !reason.trim() || Number(to) === s.params[param] || Number.isNaN(Number(to))}>
              Ask the lab to approve
            </button>
            {lastChange && lastChange.status !== 'pending' && (
              <span className={`badge ${lastChange.status === 'approved' ? 'ok' : 'critical'}`}>Last change {lastChange.status}</span>
            )}
          </div>
        </form>
      )}
    </section>
  );
}
