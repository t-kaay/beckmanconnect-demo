import { useEffect, useState } from 'react';
import { ENGINEER, INSTRUMENT, PARAMS, SCOPES, SEGMENTS, fmt } from '../state/domain';
import type { FeedItem, Scopes, SessionState } from '../state/types';

export const clock = (t: number) => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

export function remaining(s: SessionState, now: number) {
  if (!s.endsAt) return 0;
  const ref = s.phase === 'paused' && s.pausedAt ? s.pausedAt : now;
  return Math.max(0, s.endsAt - ref);
}
export function mmss(ms: number) {
  const total = Math.ceil(ms / 1000);
  const m = Math.floor(total / 60);
  const sec = total % 60;
  return `${m}:${String(sec).padStart(2, '0')}`;
}
export function minutesLeft(ms: number) {
  const m = Math.ceil(ms / 60000);
  return m <= 1 ? `${mmss(ms)} left` : `${m} min left`;
}

export function Logo({ sub }: { sub?: string }) {
  return (
    <div className="logo">
      <span className="mark" aria-hidden>
        <svg width="14" height="14" viewBox="0 0 16 16">
          <path d="M3 8.5l3.2 3.2L13 4.5" stroke="currentColor" strokeWidth="2.4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </span>
      <span>
        Beckman<span className="pipe">Connect</span>
      </span>
      {sub && <span className="badge">{sub}</span>}
    </div>
  );
}

export function EngineerId({ compact = false }: { compact?: boolean }) {
  return (
    <div className="person">
      <div className="avatar" aria-hidden>
        {ENGINEER.initials}
      </div>
      <div>
        <div style={{ fontWeight: 700 }}>
          {ENGINEER.name} <span className="muted" style={{ fontWeight: 400 }}>· {ENGINEER.role}</span>
        </div>
        {!compact && (
          <div className="row" style={{ '--gap': '6px', marginTop: 4 } as React.CSSProperties}>
            <span className="badge ok">✓ ID verified</span>
            <span className="badge">{ENGINEER.cert}</span>
            <span className="badge">{ENGINEER.region}</span>
          </div>
        )}
      </div>
    </div>
  );
}

export function InstrumentLine({ s }: { s: SessionState }) {
  return (
    <div className="row spread">
      <div>
        <div className="eyebrow">Case {s.caseId}</div>
        <h3 style={{ marginTop: 4 }}>
          {INSTRUMENT.model} · {INSTRUMENT.serial}
        </h3>
        <p className="muted" style={{ fontSize: 14 }}>
          {SEGMENTS[s.segment].lab} · {INSTRUMENT.location}
        </p>
      </div>
      <span className="badge">{SEGMENTS[s.segment].plan}</span>
    </div>
  );
}

export function Feed({ items, limit }: { items: FeedItem[]; limit?: number }) {
  const list = [...items].reverse().slice(0, limit);
  return (
    <ol className="feed" aria-live="polite">
      {list.map((f) => (
        <li key={f.id}>
          <time dateTime={new Date(f.at).toISOString()}>{clock(f.at)}</time>
          <span className={f.kind}>{f.text}</span>
        </li>
      ))}
    </ol>
  );
}

export function ScopeChecks({ scopes, blocked }: { scopes: Scopes; blocked?: number }) {
  return (
    <ul className="checks">
      {SCOPES.map((d) => (
        <li key={d.key} className={scopes[d.key] ? 'on' : 'off'}>
          <span className="ic" aria-hidden>
            {scopes[d.key] ? '✓' : '–'}
          </span>
          <span>
            {d.label}
            <span className="sr-only">{scopes[d.key] ? ' (allowed)' : ' (not allowed)'}</span>
          </span>
        </li>
      ))}
      {blocked !== undefined && (
        <li className="on">
          <span className="ic" aria-hidden style={{ color: 'var(--critical)' }}>
            ⛔
          </span>
          <span>
            Sample and result data: <strong>blocked</strong> · {blocked} {blocked === 1 ? 'request' : 'requests'} stopped
          </span>
        </li>
      )}
    </ul>
  );
}

async function sha256(text: string) {
  try {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  } catch {
    return '';
  }
}

export function recordJson(s: SessionState) {
  return {
    caseId: s.caseId,
    lab: SEGMENTS[s.segment].lab,
    instrument: { model: INSTRUMENT.model, serial: INSTRUMENT.serial },
    engineer: { name: ENGINEER.name, verified: true },
    approvedBy: s.approvedBy,
    serviceMode: s.serviceMode,
    window: { start: s.startedAt && new Date(s.startedAt).toISOString(), end: s.endedAt && new Date(s.endedAt).toISOString(), approvedMinutes: s.durationMin },
    access: s.grantedScopes,
    actions: s.diagnostics.map((d) => ({ at: new Date(d.at).toISOString(), title: d.title, lines: d.lines })),
    changes: s.changes.map((c) => ({
      setting: PARAMS[c.param].label,
      from: c.from,
      to: c.to,
      unit: PARAMS[c.param].unit,
      status: c.status,
      decidedBy: c.resolvedBy,
      signatureReason: c.signatureReason,
    })),
    blockedRequests: s.blockedCount,
    outcome: s.record?.outcome,
    summary: s.record?.summary,
    endedBy: s.record?.endedBy,
    endReason: s.record?.endReason,
  };
}

const OUTCOME = {
  resolved_remote: { label: 'Resolved remotely', cls: 'ok' },
  visit_needed: { label: 'Visit needed, parts identified', cls: 'live' },
  unresolved: { label: 'Not resolved', cls: 'critical' },
} as const;

export function ServiceRecordView({ s, canSign, onSign }: { s: SessionState; canSign: boolean; onSign?: (name: string) => void }) {
  const seg = SEGMENTS[s.segment];
  const [hash, setHash] = useState('');
  const [name, setName] = useState(seg.approver);
  const body = JSON.stringify(recordJson(s));
  useEffect(() => {
    let alive = true;
    sha256(body).then((h) => alive && setHash(h));
    return () => {
      alive = false;
    };
  }, [body]);
  if (!s.record) return null;
  const o = OUTCOME[s.record.outcome];
  const mins = s.startedAt && s.endedAt ? Math.max(1, Math.round((s.endedAt - s.startedAt) / 60000)) : 0;

  const download = () => {
    const blob = new Blob([JSON.stringify({ ...recordJson(s), signedBy: s.record?.signedBy, sha256: hash }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${s.caseId}-service-record.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };

  return (
    <section className="card record stack" style={{ '--gap': '16px' } as React.CSSProperties} aria-labelledby="rec-h">
      <div className="row spread">
        <div>
          <div className="eyebrow">Service record</div>
          <h2 id="rec-h" style={{ marginTop: 4 }}>
            {s.caseId}
          </h2>
        </div>
        <span className={`badge ${o.cls}`}>{o.label}</span>
      </div>
      <p>{s.record.summary}</p>
      <dl>
        <dt>Engineer</dt>
        <dd>{ENGINEER.name} (ID verified)</dd>
        <dt>Approved by</dt>
        <dd>{s.approvedBy}</dd>
        <dt>Session</dt>
        <dd>
          {s.startedAt && clock(s.startedAt)} to {s.endedAt && clock(s.endedAt)} · {mins} min of {s.durationMin} approved
        </dd>
        <dt>Ended</dt>
        <dd>
          by {s.record.endedBy === 'customer' ? seg.approver : s.record.endedBy === 'engineer' ? ENGINEER.short : 'system'}: {s.record.endReason}
        </dd>
        <dt>Checks run</dt>
        <dd>{s.diagnostics.length ? s.diagnostics.map((d) => d.title).join(' · ') : 'None'}</dd>
        <dt>Changes</dt>
        <dd>
          {s.changes.length
            ? s.changes.map((c) => (
                <div key={c.id}>
                  {PARAMS[c.param].label}: {fmt(c.from)} → {fmt(c.to)} {PARAMS[c.param].unit} ·{' '}
                  <strong>{c.status}</strong>
                  {c.resolvedBy ? ` by ${c.resolvedBy}` : ''}
                  {c.signatureReason ? ` (“${c.signatureReason}”)` : ''}
                </div>
              ))
            : 'None'}
        </dd>
        <dt>Data boundary</dt>
        <dd>{s.blockedCount} request{s.blockedCount === 1 ? '' : 's'} for sample or result data blocked; none left the lab</dd>
      </dl>
      <div className="hash" title="SHA-256 of the record contents">
        SHA-256 {hash || '…'}
      </div>
      <div className="row spread" style={{ borderTop: '1px solid var(--line)', paddingTop: 14 }}>
        {s.record.signedBy ? (
          <span className="badge ok">
            ✓ Signed by {s.record.signedBy} at {s.record.signedAt && clock(s.record.signedAt)}
          </span>
        ) : canSign && onSign ? (
          <form
            className="row"
            onSubmit={(e) => {
              e.preventDefault();
              onSign(name);
            }}
          >
            <label className="sr-only" htmlFor="sign-name">
              Your name
            </label>
            <input id="sign-name" className="input" style={{ width: 200 }} value={name} onChange={(e) => setName(e.target.value)} />
            <button className="btn primary" type="submit" disabled={!name.trim()}>
              Sign record
            </button>
          </form>
        ) : (
          <span className="badge">Waiting for customer signature</span>
        )}
        <button className="btn small" type="button" onClick={download}>
          Download (.json)
        </button>
      </div>
    </section>
  );
}

export function SimNote() {
  return <p className="sim-note">Design prototype. Instrument data is simulated; names are fictional. Not an official Beckman Coulter product.</p>;
}
