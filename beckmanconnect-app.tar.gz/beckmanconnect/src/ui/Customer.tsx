import { useState } from 'react';
import { ENGINEER, INSTRUMENT, PARAMS, SCOPES, SEGMENTS, fmt } from '../state/domain';
import { dispatch, useNow, useSession } from '../state/store';
import type { ChangeRequest, Scopes, SessionState } from '../state/types';
import { EngineerId, Feed, InstrumentLine, Logo, ScopeChecks, ServiceRecordView, SimNote, minutesLeft, remaining } from './shared';

export function CustomerApp() {
  const s = useSession();
  const seg = SEGMENTS[s.segment];
  return (
    <div className="app customer">
      <header className="appbar">
        <Logo />
        <span className="muted bar-meta" style={{ marginLeft: 'auto', fontSize: 13.5, textAlign: 'right' }}>
          {seg.approver} · {seg.lab}
        </span>
      </header>
      <main>
        <Body s={s} />
      </main>
      <SimNote />
    </div>
  );
}

function Body({ s }: { s: SessionState }) {
  switch (s.phase) {
    case 'choose':
      return <ChooseService s={s} />;
    case 'onsite_booked':
      return <OnsiteBooked s={s} />;
    case 'queued':
      return <Queued s={s} />;
    case 'awaiting_approval':
      return <Approve s={s} />;
    case 'declined':
      return <Declined s={s} />;
    case 'live':
    case 'paused':
      return <Live s={s} />;
    case 'ended':
      return (
        <>
          <ServiceRecordView s={s} canSign onSign={(name) => dispatch({ type: 'SIGN_RECORD', at: Date.now(), name })} />
          <section className="card stack">
            <h3>Session activity</h3>
            <Feed items={s.feed} />
          </section>
        </>
      );
  }
}

function CaseCard({ s }: { s: SessionState }) {
  return (
    <section className="card stack">
      <InstrumentLine s={s} />
      <div className="row" style={{ '--gap': '8px' } as React.CSSProperties}>
        <span className="badge critical">
          <span className="dot" /> Instrument down
        </span>
        <span style={{ fontSize: 14 }}>{INSTRUMENT.issue}</span>
      </div>
    </section>
  );
}

function ChooseService({ s }: { s: SessionState }) {
  const seg = SEGMENTS[s.segment];
  const choose = (mode: 'remote' | 'hybrid' | 'onsite') => dispatch({ type: 'CHOOSE_SERVICE', at: Date.now(), mode });
  return (
    <>
      <CaseCard s={s} />
      <div>
        <h1>How would you like this fixed?</h1>
        <p className="muted" style={{ marginTop: 6 }}>
          All three are covered by your {seg.plan}. You can switch until an engineer connects.
        </p>
      </div>
      <div className="grid3">
        <div className="option recommended">
          <div className="row spread">
            <h3>Remote</h3>
            <span className="badge brand">Fastest</span>
          </div>
          <dl>
            <dt>Starts</dt>
            <dd>In about 15 min</dd>
            <dt>Downtime</dt>
            <dd>Usually hours</dd>
            <dt>Cost</dt>
            <dd>Included</dd>
          </dl>
          <p className="muted" style={{ fontSize: 13 }}>
            You approve what they can see and do. Pause or end any time.
          </p>
          <button className="btn primary block" onClick={() => choose('remote')}>
            Start remote
          </button>
        </div>
        <div className="option">
          <h3>Hybrid</h3>
          <dl>
            <dt>Starts</dt>
            <dd>In about 15 min</dd>
            <dt>Downtime</dt>
            <dd>Hours to 1 day</dd>
            <dt>Cost</dt>
            <dd>Included</dd>
          </dl>
          <p className="muted" style={{ fontSize: 13 }}>
            Remote diagnosis first. If a visit is needed, the engineer arrives with the right part.
          </p>
          <button className="btn block" onClick={() => choose('hybrid')}>
            Start hybrid
          </button>
        </div>
        <div className="option">
          <h3>Onsite</h3>
          <dl>
            <dt>Starts</dt>
            <dd>Thursday, 9:00</dd>
            <dt>Downtime</dt>
            <dd>2 to 3 days</dd>
            <dt>Cost</dt>
            <dd>Included</dd>
          </dl>
          <p className="muted" style={{ fontSize: 13 }}>
            An engineer visits the lab. Remote time is credited if a visit follows.
          </p>
          <button className="btn block" onClick={() => choose('onsite')}>
            Book a visit
          </button>
        </div>
      </div>
      <p className="muted" style={{ fontSize: 13 }}>
        On instruments enrolled in BeckmanConnect, 66% of issues are resolved remotely, about 2 days sooner than waiting for a visit.
      </p>
    </>
  );
}

function OnsiteBooked({ s }: { s: SessionState }) {
  return (
    <>
      <CaseCard s={s} />
      <section className="card stack">
        <span className="badge ok" style={{ alignSelf: 'flex-start' }}>
          ✓ Visit booked
        </span>
        <h2>An engineer will visit {s.onsiteVisit}</h2>
        <p className="muted">Your instrument stays down until then. If you change your mind, remote can usually start within 15 minutes.</p>
        <div className="row">
          <button className="btn primary" onClick={() => dispatch({ type: 'CHOOSE_SERVICE', at: Date.now(), mode: 'remote' })}>
            Try remote first
          </button>
        </div>
      </section>
    </>
  );
}

function Queued({ s }: { s: SessionState }) {
  return (
    <>
      <CaseCard s={s} />
      <section className="card stack" style={{ '--gap': '16px' } as React.CSSProperties}>
        <div className="row" style={{ '--gap': '10px' } as React.CSSProperties}>
          <div className="spinner" aria-hidden />
          <h2>Your engineer is reviewing the case</h2>
        </div>
        <EngineerId />
        <p className="muted">
          {ENGINEER.short.split(' ')[0]} will send an access request. Nothing connects until you approve it, and you choose what is allowed.
        </p>
      </section>
    </>
  );
}

function Declined({ s }: { s: SessionState }) {
  return (
    <>
      <CaseCard s={s} />
      <section className="card stack">
        <h2>You declined the request</h2>
        <p className="muted">
          Reason: {s.declineReason}. {ENGINEER.short} can send a new request, or you can book a visit instead.
        </p>
        <div className="row">
          <button className="btn" onClick={() => dispatch({ type: 'CHOOSE_SERVICE', at: Date.now(), mode: 'onsite' })}>
            Book a visit instead
          </button>
        </div>
      </section>
    </>
  );
}

const DURATIONS = [15, 30, 45, 60, 90];

function Approve({ s }: { s: SessionState }) {
  const seg = SEGMENTS[s.segment];
  const [scopes, setScopes] = useState<Scopes>(s.requestedScopes);
  const [duration, setDuration] = useState(s.durationMin);
  const [declining, setDeclining] = useState(false);
  const [reason, setReason] = useState('Instrument is running samples');

  return (
    <>
      <section className="card stack" style={{ '--gap': '16px' } as React.CSSProperties} aria-labelledby="approve-h">
        <div>
          <div className="eyebrow">Access request · case {s.caseId}</div>
          <h1 id="approve-h" style={{ marginTop: 6 }}>
            {ENGINEER.name} wants to connect to your {INSTRUMENT.model}
          </h1>
        </div>
        <EngineerId />
        <p style={{ fontSize: 14 }} className="muted">
          Only Beckman support staff in your region, signed in with two-factor authentication, can connect. A new one-time password is made for this
          session.
        </p>
        {s.requestNote && (
          <blockquote style={{ margin: 0, padding: '10px 14px', background: 'var(--sunken)', borderRadius: 8, fontSize: 14 }}>
            “{s.requestNote}”
          </blockquote>
        )}
      </section>

      <div className="grid2">
        <section className="card" aria-labelledby="scope-h">
          <h3 id="scope-h">What they can do</h3>
          <p className="muted" style={{ fontSize: 13.5, margin: '4px 0 6px' }}>
            Turn off anything you're not comfortable with.
          </p>
          <div>
            {SCOPES.map((d) => {
              const requested = s.requestedScopes[d.key];
              const locked = !!d.lockedReason || !requested;
              return (
                <div className="scope" key={d.key}>
                  <div>
                    <div className="t" id={`sc-${d.key}`}>
                      {d.label}
                    </div>
                    <div className="d">{d.lockedReason ?? (requested ? d.detail : 'Not requested.')}</div>
                  </div>
                  <label className="switch">
                    <input
                      type="checkbox"
                      aria-labelledby={`sc-${d.key}`}
                      checked={scopes[d.key] && !d.lockedReason}
                      disabled={locked}
                      onChange={(e) => setScopes({ ...scopes, [d.key]: e.target.checked })}
                    />
                    <span />
                  </label>
                </div>
              );
            })}
          </div>
        </section>

        <section className="card stack" aria-labelledby="always-h">
          <h3 id="always-h">Always true</h3>
          <ul className="checks">
            <li className="on">
              <span className="ic">✓</span>
              <span>Experiment and sample data stay in the lab. Requests for them are blocked and shown to you.</span>
            </li>
            <li className="on">
              <span className="ic">✓</span>
              <span>No inbound connection to your network. Outbound on port 443 only, TLS 1.2 with AES-256.</span>
            </li>
            <li className="on">
              <span className="ic">✓</span>
              <span>You can pause or end at any time. Access closes automatically when time runs out.</span>
            </li>
            <li className="on">
              <span className="ic">✓</span>
              <span>Every action is logged in a signed record you keep{seg.eSignature ? ', with e-signatures for changes' : ''}.</span>
            </li>
          </ul>
          <label className="field" style={{ marginTop: 'auto' }}>
            How long
            <select className="input" value={duration} onChange={(e) => setDuration(Number(e.target.value))}>
              {DURATIONS.filter((d) => d <= s.durationMin).map((d) => (
                <option key={d} value={d}>
                  {d} minutes{d === s.durationMin ? ' (requested)' : ''}
                </option>
              ))}
            </select>
          </label>
        </section>
      </div>

      {!declining ? (
        <div className="row">
          <button
            className="btn primary"
            style={{ minHeight: 48, padding: '10px 22px' }}
            onClick={() => dispatch({ type: 'APPROVE', at: Date.now(), scopes, durationMin: duration, approver: seg.approver })}
          >
            Approve {duration}-minute session
          </button>
          <button className="btn" onClick={() => setDeclining(true)}>
            Decline
          </button>
        </div>
      ) : (
        <section className="card stack">
          <label className="field">
            Why are you declining?
            <select className="input" value={reason} onChange={(e) => setReason(e.target.value)}>
              <option>Instrument is running samples</option>
              <option>Need IT to review first</option>
              <option>Prefer an onsite visit</option>
              <option>Not comfortable with remote access</option>
            </select>
          </label>
          <div className="row">
            <button className="btn danger" onClick={() => dispatch({ type: 'DECLINE', at: Date.now(), reason })}>
              Decline request
            </button>
            <button className="btn ghost" onClick={() => setDeclining(false)}>
              Back
            </button>
          </div>
        </section>
      )}
    </>
  );
}

function Live({ s }: { s: SessionState }) {
  const now = useNow(1000);
  const seg = SEGMENTS[s.segment];
  const paused = s.phase === 'paused';
  const pending = s.changes.find((c) => c.status === 'pending');
  const left = remaining(s, now);
  return (
    <>
      <div className={`livebar${paused ? ' paused' : ''}`} role="status">
        <span className="who">
          <span className={`dot${paused ? '' : ' pulse'}`} style={{ color: paused ? 'var(--muted)' : 'var(--live-fill)' }} />
          {paused ? 'Session paused' : `${ENGINEER.short.split(' ')[0]} is connected`}
        </span>
        <span className="grow" style={{ fontSize: 14 }}>
          {paused ? `${ENGINEER.short.split(' ')[0]} can't see or do anything.` : s.currentActivity} · {minutesLeft(left)}
        </span>
        {paused ? (
          <button className="btn primary small" onClick={() => dispatch({ type: 'RESUME', at: Date.now() })}>
            Resume
          </button>
        ) : (
          <button className="btn small" onClick={() => dispatch({ type: 'PAUSE', at: Date.now() })}>
            Pause
          </button>
        )}
        <button className="btn danger small" onClick={() => dispatch({ type: 'END', at: Date.now(), by: 'customer', reason: 'ended by the lab' })}>
          End session
        </button>
      </div>

      {pending && <ChangeApproval c={pending} eSignature={seg.eSignature} approver={seg.approver} />}

      <div className="grid2">
        <section className="card stack" aria-labelledby="feed-h">
          <div className="row spread">
            <h3 id="feed-h">What's happening</h3>
            <span className="badge">Live log</span>
          </div>
          <Feed items={s.feed} />
        </section>
        <div className="stack" style={{ '--gap': '16px' } as React.CSSProperties}>
          <section className="card stack">
            <EngineerId compact />
            <h3 style={{ marginTop: 4 }}>What {ENGINEER.short.split(' ')[0]} can do</h3>
            <ScopeChecks scopes={s.grantedScopes} blocked={s.blockedCount} />
          </section>
          <section className="card tight row" style={{ '--gap': '10px' } as React.CSSProperties}>
            <span className="badge ok">✓</span>
            <span style={{ fontSize: 14 }}>
              <strong>Your network:</strong> no inbound access. Outbound 443, encrypted.
            </span>
          </section>
          <QCStatus s={s} />
        </div>
      </div>
    </>
  );
}

function QCStatus({ s }: { s: SessionState }) {
  const last = [...s.diagnostics].reverse().find((d) => d.kind === 'qc');
  if (!last) return null;
  return (
    <section className={`card tight result ${last.pass ? 'pass' : 'fail'}`} style={{ borderLeftWidth: 4 }}>
      <div className="row spread">
        <strong>{last.title}</strong>
        <span className="muted mono">{new Date(last.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}</span>
      </div>
      <ul>
        {last.lines.map((l) => (
          <li key={l}>{l}</li>
        ))}
      </ul>
    </section>
  );
}

function ChangeApproval({ c, eSignature, approver }: { c: ChangeRequest; eSignature: boolean; approver: string }) {
  const meta = PARAMS[c.param];
  const [sig, setSig] = useState('');
  return (
    <section className="change-card stack" role="alertdialog" aria-labelledby="chg-h" aria-describedby="chg-d">
      <div className="eyebrow">Approval needed</div>
      <h2 id="chg-h">{ENGINEER.short.split(' ')[0]} wants to change a setting</h2>
      <div>
        <div style={{ fontWeight: 600 }}>{meta.label}</div>
        <div className="delta" aria-label={`from ${fmt(c.from)} to ${fmt(c.to)} ${meta.unit}`}>
          <span className="from">
            {fmt(c.from)} {meta.unit}
          </span>
          <span aria-hidden>→</span>
          <span>
            {fmt(c.to)} {meta.unit}
          </span>
        </div>
      </div>
      <p id="chg-d" style={{ fontSize: 14 }}>
        <strong>Why:</strong> {c.reason}
      </p>
      <p className="muted" style={{ fontSize: 13 }}>
        The old value is saved in the record and can be restored.
      </p>
      {eSignature && (
        <label className="field">
          Reason for approval (e-signature as {approver})
          <input className="input" placeholder="e.g. Approved per SOP-114, deviation DV-2291" value={sig} onChange={(e) => setSig(e.target.value)} />
        </label>
      )}
      <div className="row">
        <button
          className="btn primary"
          disabled={eSignature && !sig.trim()}
          onClick={() => dispatch({ type: 'RESOLVE_CHANGE', at: Date.now(), id: c.id, approve: true, by: approver, signatureReason: eSignature ? sig : undefined })}
        >
          {eSignature ? 'Sign and approve change' : 'Approve change'}
        </button>
        <button className="btn" onClick={() => dispatch({ type: 'RESOLVE_CHANGE', at: Date.now(), id: c.id, approve: false, by: approver })}>
          Decline
        </button>
      </div>
    </section>
  );
}
