import { expect, test, type Page } from '@playwright/test';

const shots = process.env.SHOTS === '1';
const snap = async (page: Page, name: string) => {
  if (shots) await page.screenshot({ path: `e2e/shots/${name}.png`, fullPage: false });
};

test('full remote fix in the split demo', async ({ page }) => {
  await page.goto('./');
  await page.getByRole('button', { name: 'Reset' }).click();
  const lab = page.getByRole('region', { name: 'Lab view' });
  const eng = page.getByRole('region', { name: 'Engineer view' });
  await expect(page.getByText('NEXT · LAB')).toBeVisible();
  await snap(page, '01-choose');

  await lab.getByRole('button', { name: 'Start remote' }).click();
  await expect(eng.getByRole('heading', { name: 'Request access' })).toBeVisible();
  await snap(page, '02-request');
  await eng.getByRole('button', { name: 'Send access request' }).click();

  await expect(lab.getByRole('heading', { name: /wants to connect/ })).toBeVisible();
  await snap(page, '03-approve');
  await lab.getByRole('button', { name: /Approve 60-minute session/ }).click();

  await expect(lab.getByText('Dana is connected')).toBeVisible();
  await eng.getByRole('button', { name: 'Run daily QC' }).click();
  await expect(eng.getByText('Daily QC failed').first()).toBeVisible();
  await eng.getByRole('button', { name: /Open experiment data/ }).click();
  await expect(lab.getByText(/1 request stopped/)).toBeVisible();
  await eng.getByRole('button', { name: 'Pull laser log' }).click();
  await eng.getByRole('button', { name: 'Ask the lab to approve' }).click();

  await expect(lab.getByRole('alertdialog')).toBeVisible();
  await snap(page, '04-change');
  await lab.getByRole('button', { name: 'Approve change' }).click();
  await eng.getByRole('button', { name: 'Run daily QC' }).click();
  await expect(eng.getByText('Daily QC passed').first()).toBeVisible();
  await snap(page, '05-pass');

  await eng.getByRole('button', { name: 'End session' }).click();
  await expect(lab.getByText('Resolved remotely')).toBeVisible();
  await lab.getByRole('button', { name: 'Sign record' }).click();
  await expect(lab.getByText(/Signed by Marcus Lee/)).toBeVisible();
  await expect(eng.getByText(/Signed by Marcus Lee/)).toBeVisible();
  await expect(page.getByText('DONE')).toBeVisible();
  await snap(page, '06-record');
});

test('pause freezes the engineer; GxP needs e-signature', async ({ page }) => {
  await page.goto('./');
  await page.getByRole('button', { name: 'Commercial / GxP' }).click();
  const lab = page.getByRole('region', { name: 'Lab view' });
  const eng = page.getByRole('region', { name: 'Engineer view' });
  await lab.getByRole('button', { name: 'Start remote' }).click();
  await eng.getByRole('button', { name: 'Send access request' }).click();
  await lab.getByRole('button', { name: /Approve 45-minute session/ }).click();
  await lab.getByRole('button', { name: 'Pause' }).click();
  await expect(eng.getByText('Paused by customer')).toBeVisible();
  await expect(eng.getByRole('button', { name: 'Run daily QC' })).toBeDisabled();
  await lab.getByRole('button', { name: 'Resume' }).click();
  await eng.getByRole('button', { name: 'Ask the lab to approve' }).click();
  const approve = lab.getByRole('button', { name: 'Sign and approve change' });
  await expect(approve).toBeDisabled();
  await lab.getByPlaceholder(/SOP-114/).fill('Approved per SOP-114');
  await approve.click();
  await expect(lab.getByText(/approved the change with e-signature/)).toBeVisible();
});

test('two separate windows stay in sync', async ({ context }) => {
  const a = await context.newPage();
  await a.goto('./');
  await a.getByRole('button', { name: 'Reset' }).click();
  const customer = await context.newPage();
  const engineer = await context.newPage();
  await customer.goto('./#/customer');
  await engineer.goto('./#/engineer');
  await customer.getByRole('button', { name: 'Start remote' }).click();
  await engineer.getByRole('button', { name: 'Send access request' }).click();
  await expect(customer.getByRole('heading', { name: /wants to connect/ })).toBeVisible();
  await customer.getByRole('button', { name: /Approve/ }).first().click();
  await expect(engineer.getByText('Connected', { exact: true })).toBeVisible();
});

test('phone width: tabs follow the next action, no horizontal scroll', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('./');
  await page.getByRole('button', { name: 'Reset' }).click();
  await page.getByRole('button', { name: 'Start remote' }).click();
  await expect(page.getByRole('tab', { name: /Field engineer/ })).toHaveAttribute('aria-selected', 'true');
  await page.getByRole('button', { name: 'Send access request' }).click();
  await expect(page.getByRole('tab', { name: /Lab/ })).toHaveAttribute('aria-selected', 'true');
  await snap(page, '07-phone-approve');
  await page.getByRole('button', { name: /Approve 60-minute/ }).click();
  await page.getByRole('tab', { name: /Field engineer/ }).click();
  await page.getByRole('button', { name: 'Run daily QC' }).click();
  await snap(page, '08-phone-engineer');
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  expect(overflow).toBeLessThanOrEqual(0);
});
